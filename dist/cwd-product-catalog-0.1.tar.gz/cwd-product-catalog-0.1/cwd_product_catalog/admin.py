from django.contrib import admin
from cms.admin.placeholderadmin import PlaceholderAdmin
from product_catalog.models import CWDProduct, Category

class CWDProductAdmin(PlaceholderAdmin):
    prepopulated_fields = {"slug": ("name",)}
    list_display = ('name',)
    list_filter = ('category', )

class CategoryAdmin(PlaceholderAdmin):
    pass

admin.site.register(Category, CategoryAdmin)
admin.site.register(CWDProduct, CWDProductAdmin)
